function Adestramento(){
    return(
        <div>Adestramento</div>
    )
}

export default Adestramento