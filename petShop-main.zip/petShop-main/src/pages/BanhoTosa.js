function BanhoTosa(){
    return(
        <div>Banho e tosa</div>
    )
}

export default BanhoTosa