function HotelResort(){
    return(
        <div> hotel resort</div>
    )
}

export default HotelResort